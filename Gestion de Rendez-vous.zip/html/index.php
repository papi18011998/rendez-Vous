<!DOCTYPE html>
<html>
<head>
	<title>Kagn-La plateforme de prise de rendez-vous</title>
	<link rel="stylesheet" type="text/css" href="style/css/bootstrap.min.css">
	<script type="text/javascript" src="style/js/jquery-min.js"></script>
</head>
<body>
	<div class="cacheContain"><i class="cache">&equiv;</i></div>
	<div id="menu" style="display: block;">
		<a href=""><img src="image/logo.png" alt="Ceci contient le logo" class="logo"></a>
		<ul>
			<li><a href="">Accueil</a></li>
			<li><a href="">Présentation</a></li>
			<li><a href="vue/connexionVue.php">Se Connecter</a></li>
		</ul>
	</div>
	<img src="image/doctor.jpg" class="fond" alt="photo">
	<script type="text/javascript">
		$(document).ready(function() {
			var menu=$("#menu")
			$(".cache").click(function(){
				menu.slideToggle('slow')
			})
		})
	</script>
</body>
</html>
