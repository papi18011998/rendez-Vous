<?php
    try {
        $pdo=new PDO("mysql:host=127.0.0.1;dbname=Rendez-Vous","debian-sys-maint","5vkpM4go2dYyq2xF");
    } catch (\Throwable $th) {
        echo $th;
    }