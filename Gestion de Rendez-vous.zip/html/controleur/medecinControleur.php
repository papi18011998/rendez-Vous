<?php
session_start();
$erreur=[];
include('../modele/medecin.php');
include('../utilitaire/DataBaseHelper.php');
if (isset($_POST['demarre'])) {
    $sqlUpdate="UPDATE RendezVous SET etat=? WHERE id=?";
    $req=$pdo->prepare($sqlUpdate);
    $req->execute([1,$_POST['id']]);
    $sqlUpdateMedecin="UPDATE Medecin SET disponibilite=? WHERE idMedecin=?";
    $reqM=$pdo->prepare($sqlUpdateMedecin);
    $reqM->execute([1,$_SESSION['id']]);
    header("location:../vue/chronoRv.php");
}
if(isset($_POST['validerRv'])){
    $sqlUpdateMedecin="UPDATE Medecin SET disponibilite=? WHERE idMedecin=?";
    $reqM=$pdo->prepare($sqlUpdateMedecin);
    $reqM->execute([0,$_SESSION['id']]);
    $_SESSION['reussi']="Le rendez-vous s'est bien passe";
    header("location:../vue/medecinVue.php");
}
if(isset($_POST['ajouter'])){
    if (isset($_POST['prenomMedecin']) && empty($_POST['prenomMedecin'])) {
        $erreur['prenom']='Le prenom est obligatoire';
    }
    if (isset($_POST['nomMedecin']) && empty($_POST['nomMedecin'])) {
        $erreur['nom']='Le nom est obligatoire';
    }
    if (isset($_POST['email']) && empty($_POST['email'])) {
        $erreur['email']="L'email est obligatoire";
    }
    if (isset($_POST['loginMedecin']) && empty($_POST['loginMedecin'])) {
        $erreur['login']='Le login est obligatoire';
    }
    if (isset($_POST['pwdMedecin']) && empty($_POST['pwdMedecin'])) {
        $erreur['pwd']='Le mot de passe est obligatoire';
    }
    if (isset($_POST['tel']) && empty($_POST['tel'])) {
        $erreur['tel']='Le telephone est obligatoire';
    }
    if (!empty($erreur)) {
        $_SESSION['erreur']=$erreur;
        header('location:../vue/medecinSetting.php');
    }elseif(empty($erreur)){
        $medecin=new Medecin();
        $medecin->setPrenom(htmlspecialchars($_POST['prenomMedecin']));
        $medecin->setNom(htmlspecialchars($_POST['nomMedecin']));
        $medecin->setLogin(htmlspecialchars($_POST['loginMedecin']));
        $medecin->setDisponibilite(0);
        $medecin->setEmail(htmlspecialchars($_POST['email']));
        $medecin->setPwd(sha1($_POST['pwdMedecin']));
        $medecin->setTel($_POST['tel']);
        $medecin->setIdS($_POST['service']);
        $medecin->setIdD($_POST['domaine']);
        $sqlInsertMedecin="INSERT INTO Medecin VALUES(?,?,?,?,?,?,?,?,?,?)";
        $reqMedecin=$pdo->prepare($sqlInsertMedecin);
        $reqMedecin->execute(array(null,$medecin->getPrenom(),$medecin->getNom(),$medecin->getDisponibilite(),$medecin->getEmail(),$medecin->getLogin(),$medecin->getPwd(),$medecin->getTel(),$medecin->getIdS(),$medecin->getIdD()));
        $_SESSION['success']='Le medecin a bien été ajouté';
        header('location:../vue/medecinSetting.php');
    }
}
if (isset($_POST['delete'])) {
    $sqlDel="DELETE FROM Medecin WHERE idMedecin=?";
    $reqDel=$pdo->prepare($sqlDel);
    $reqDel->execute([$_POST['sup']]);
    $_SESSION['supprime']="Supprime avec succes";
    header('location:../vue/medecinSetting.php');
}
?>