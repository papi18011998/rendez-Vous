<?php 
    session_start();
    include('../utilitaire/DataBaseHelper.php');
    $erreur=[];
    if (isset($_POST['soumettre'])) {
       if(isset($_POST['login']) && empty($_POST['login'])){
           $erreur['login']="Renseigner le login";
       }
        if(isset($_POST['pwd']) && empty($_POST['pwd'])){
            $erreur['pwd']="Renseigner le mot de passe";
        }
        if(isset($_POST['profil'])){
           if ($_POST['profil']!='medecin' && $_POST['profil']!='secretaire' && $_POST['profil']=='') {
            $erreur['profil']="Rensigner un bon profil";
           }

        }

       if (empty($erreur)) {
          if ($_POST['profil']=='medecin') {
            $sql="SELECT * FROM Medecin WHERE login=? AND pwd=?";
            $req=$pdo->prepare($sql);
            $req->execute(array($_POST['login'],sha1($_POST['pwd'])));
            if($donne=$req->fetch()){
                $_SESSION['login']=$donne['login'];
                $_SESSION['prenom']=$donne['prenomMedecin'];
                $_SESSION['nom']=$donne['nomMedecin'];
                $_SESSION['id']=$donne['idMedecin'];
                header("location:../vue/medecinVue.php");
            }
            else{
                header("location:../vue/connexionVue.php");
            }
             
          }if($_POST['profil']=='secretaire'){
            $sql="SELECT * FROM Secretariat WHERE login=? AND pwd=?";
            $req=$pdo->prepare($sql);
            $req->execute(array($_POST['login'],sha1($_POST['pwd'])));
            if($donne=$req->fetch()){
                $_SESSION['login']=$donne['login'];
                $_SESSION['prenom']=$donne['prenomSecretaire'];
                $_SESSION['nom']=$donne['nomSecretaire'];
                $_SESSION['id']=$donne['idSecretariat'];
                header("location:../vue/secretaireVue.php");
            }
            else{
                header("location:../vue/connexionVue.php");
            }
          }


          if($_POST['profil']=='admin'){
            $sql="SELECT * FROM Admin WHERE login=? AND pwdAd=?";
            $req=$pdo->prepare($sql);
            $req->execute(array($_POST['login'],$_POST['pwd']));
            if($donne=$req->fetch()){
                $_SESSION['login']=$donne['login'];
                $_SESSION['prenom']=$donne['prenomAd'];
                $_SESSION['nom']=$donne['nomAd'];
                $_SESSION['id']=$donne['id'];
                header("location:../vue/adminVue.php");
            }
            else{
                header("location:../vue/connexionVue.php");
            }
          }
          
       } else {
        $_SESSION['erreur']=$erreur;
        header("location:../vue/connexionVue.php"); 
       }
       
    }

    
    
?>