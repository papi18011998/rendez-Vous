<?php
    session_start();
    $erreur=[];
    include('../utilitaire/DataBaseHelper.php');
    include('../modele/secretaire.php');
    $heure=["8","9","10","11","12","13","15","16","17"];
 if (isset($_POST['organiser'])) {
     if (isset($_POST['prenom']) && empty($_POST['prenom'])) {
         $erreur['prenom']="Le champ prenom est obligatoire";
     }
     if (isset($_POST['nom']) && empty($_POST['nom'])) {
        $erreur['nom']="Le champ nom est obligatoire";
     }
     if (isset($_POST['adresse']) && empty($_POST['adresse'])) {
        $erreur['adresse']="Le champ adresse est obligatoire";
     }
     if (isset($_POST['date']) && empty($_POST['date'])) {
        $erreur['date']="Le champ date de tenue est obligatoire";
     }
     if (isset($_POST['date']) && !in_array($_POST['heure'],$heure)) {
        $erreur['date']="Le champ heure doit etre entre 08heures et 13 heures ou 15heures et 17heures";
     }
     if (!empty($erreur)) {
         $_SESSION['erreur']=$erreur;
         header("location:../vue/secretaireVue.php");
     }else{
        // INSERTION DE PATIENT
        $sqlInsertPatient="INSERT INTO Patient VALUES(?,?,?,?)";
        $req=$pdo->prepare($sqlInsertPatient);
        $req->execute(array(null,$_POST['nom'],$_POST['prenom'],$_POST['adresse']));
        $sql="SELECT idPatient FROM Patient";
        $r=$pdo->prepare($sql);
        $r->execute([]);
        $i=0;
        while($fetch=$r->fetch()){
           $i=$fetch['idPatient'];
        }
        //MODIFICATION DU PROFIL DU MEDECIN
        $sqlUpdateMedecin="UPDATE  Medecin SET disponibilite=? WHERE idMedecin=?";
        $req=$pdo->prepare($sqlUpdateMedecin);
        $req->execute(array(1,$_POST['medecin']));
        // INSERTION DE RENDEZ VOUS
        $sqlInsertRv="INSERT INTO RendezVous VALUES (?,?,?,?,?,?)";
        $req=$pdo->prepare($sqlInsertRv);
        $req->execute(array($i,$_POST['medecin'],$_SESSION['id'],$_POST['date'],$_POST['heure'],0));
        echo $i;
        $_SESSION['insert']='Rendez-vous comptabilise avec succes';
        header("location:../vue/secretaireVue.php");
      }
 }
 if (isset($_POST['del'])) {
    $sqlDelete="DELETE FROM RendezVous WHERE id=?";
    $req=$pdo->prepare($sqlDelete);
    $req->execute([$_POST['id']]);
    $_SESSION['delete']='Supprime avec succes';
    header("location:../vue/secretaireVue.php");
    echo $_POST['id'];
 }
 if(isset($_POST['ajouter'])){
   if (isset($_POST['prenomSecretaire']) && empty($_POST['prenomSecretaire'])) {
       $erreur['prenom']='Le prenom est obligatoire';
   }
   if (isset($_POST['nomSecretaire']) && empty($_POST['nomSecretaire'])) {
       $erreur['nom']='Le nom est obligatoire';
   }
   if (isset($_POST['email']) && empty($_POST['email'])) {
       $erreur['email']="L'email est obligatoire";
   }
   if (isset($_POST['loginSecretaire']) && empty($_POST['loginSecretaire'])) {
       $erreur['login']='Le login est obligatoire';
   }
   if (isset($_POST['pwdSecretaire']) && empty($_POST['pwdSecretaire'])) {
       $erreur['pwd']='Le mot de passe est obligatoire';
   }
   if (isset($_POST['tel']) && empty($_POST['tel'])) {
       $erreur['tel']='Le telephone est obligatoire';
   }
   if (!empty($erreur)) {
       $_SESSION['erreur']=$erreur;
       header('location:../vue/secretaireSetting.php');
   }elseif(empty($erreur)){
       $secretaire=new Secretaire();
       $secretaire->setPrenom(htmlspecialchars($_POST['prenomSecretaire']));
       $secretaire->setNom(htmlspecialchars($_POST['nomSecretaire']));
       $secretaire->setLogin(htmlspecialchars($_POST['loginSecretaire']));
       $secretaire->setEmail(htmlspecialchars($_POST['email']));
       $secretaire->setPwd(sha1($_POST['pwdSecretaire']));
       $secretaire->setTel($_POST['tel']);
       $sqlInsertSecretaire="INSERT INTO Secretariat VALUES(?,?,?,?,?,?,?)";
       $reqSecretaire=$pdo->prepare($sqlInsertSecretaire);
       $reqSecretaire->execute(array(null,$secretaire->getNom(),$secretaire->getPrenom(),$secretaire->getEmail(),$secretaire->getLogin(),$secretaire->getPwd(),$secretaire->getTel()));
       $_SESSION['success']='La secretaire a bien été ajouté';
       header('location:../vue/secretaireSetting.php');
   }
}
if (isset($_POST['delete'])) {
    $sqlDel="DELETE FROM Secretariat WHERE idSecretariat=?";
    $reqDel=$pdo->prepare($sqlDel);
    $reqDel->execute([$_POST['sup']]);
    $_SESSION['supprime']="Supprime avec succes";
    header('location:../vue/secretaireSetting.php');
}
?>