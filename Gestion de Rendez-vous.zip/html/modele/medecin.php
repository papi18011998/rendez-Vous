<?php
 class Medecin{
     private $prenom;
     private $nom;
     private $login;
     private $disponibilite;
     private $email;
     private $pwd;
     private $tel;
     private $idService;
     private $idDomaine;
     public function __construct(){}
     //GETTERS 
     public function getPrenom(){
         return $this->prenom;
     }
     public function getNom(){
        return $this->nom;
    }
    public function getLogin(){
        return $this->login;
    }
    public function getDisponibilite(){
        return $this->disponibilite;
    }
    public function getEmail(){
        return $this->email;
    }
    public function getPwd(){
        return $this->pwd;
    }
    public function getTel(){
        return $this->tel;
    }
    public function getIdS(){
        return $this->idService;
    }
    public function getIdD(){
        return $this->idDomaine;
    }
     //SETTERS
     public function setPrenom($prenomp){
         $this->prenom=$prenomp;
     }
     public function setNom($nomp){
        $this->nom=$nomp;
    }
    public function setLogin($loginp){
        $this->login=$loginp;
    }
    public function setDisponibilite($disponibilitep){
        $this->disponibilite=$disponibilitep;
    }
    public function setEmail($emailp){
        $this->email=$emailp;
    }
    public function setPwd($pwdp){
        $this->pwd=$pwdp;
    }
    public function setTel($telp){
        $this->tel=$telp;
    }
    public function setIdS($idSp){
        $this->idService=$idSp;
    }
    public function setIdD($idDp){
        $this->idDomaine=$idDp;
    }

}
?>
