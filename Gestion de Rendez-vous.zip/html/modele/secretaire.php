<?php 
    class Secretaire{
        private $prenom;
        private $nom;
        private $email;
        private $login;
        private $pwd;
        private $tel;
        public function __construct(){}
            //GETTERS 
            public function getPrenom(){
                return $this->prenom;
            }
            public function getNom(){
               return $this->nom;
           }
           public function getLogin(){
               return $this->login;
           }
           public function getEmail(){
               return $this->email;
           }
           public function getPwd(){
               return $this->pwd;
           }
           public function getTel(){
               return $this->tel;
           }
            //SETTERS
            public function setPrenom($prenomp){
                $this->prenom=$prenomp;
            }
            public function setNom($nomp){
               $this->nom=$nomp;
           }
           public function setLogin($loginp){
               $this->login=$loginp;
           }
           public function setEmail($emailp){
               $this->email=$emailp;
           }
           public function setPwd($pwdp){
               $this->pwd=$pwdp;
           }
           public function setTel($telp){
               $this->tel=$telp;
           }
    }
?>