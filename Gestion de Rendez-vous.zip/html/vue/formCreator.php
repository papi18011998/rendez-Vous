<?php   
class Formulaire 
{
  public function __construct(){} 
  public function SimpleInput($label,$type,$name,$placeHolder,$id){
    echo '<label>'.$label.'</label>'; 
    echo '<input type="'.$type.'" name="'.$name.'" id="'.$id.'" placeholder="'.$placeHolder.'" class="form-control"/>';
  }
  public function numberInput($label,$name,$placeHolder,$min,$max,$id){
    echo '<label>'.$label.'</label>'; 
    echo '<input type="number" max="'.$max.'" id="'.$id.'" min="'.$min.'" name="'.$name.'" placeholder="'.$placeHolder.'" class="form-control"/>';
  }
  public function optionInput($value,$valueAffiche){
    echo'<option value="'.$value.'">'.$valueAffiche.'</option>';
  }

  public function buttonInput($type,$name,$value,$class){
    echo '<input type="'.$type.'" name="'.$name.'" value="'.$value.'" class="'.$class.'"/>';
  }
  public function CheckInput($id,$label,$type,$value,$name){
    echo '<label for="'.$id.'">'.$label.'</label>'; 
    echo '<input type="'.$type.'" name="'.$name.'" value="'.$value.'" id="'.$id.'"/>';
  }
}
?>
