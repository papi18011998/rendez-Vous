<?php session_start();?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Page de connexion</title>
    <link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<script type="text/javascript" src="style/js/jquery-min.js"></script>
</head>
<body class="bodyConnexion">
    <div class="divConnexion col-md-10">
            <?php 
                if(array_key_exists("erreur", $_SESSION)){  
                    echo "<div class='alert alert-danger'>"; 
                        print_r(implode("<br/> ",$_SESSION['erreur']));
                    echo"</div>"; 
                unset($_SESSION["erreur"]);
            }?>
            <form action="../controleur/connexionControleur.php" method="POST">
            <?php 
                include('formCreator.php');
                $form=new Formulaire();
                $form->SimpleInput("Donnez votre login","text","login","login","login");
                echo'<br/>';
                $form->SimpleInput("Donnez votre mot de passe","password","pwd","mot de passe","pwd");
                echo'<br/>';
                echo'<center>';
                $form->CheckInput("med","Medecin","radio","medecin","profil");
                echo'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                $form->CheckInput("sec","Secretaire","radio","secretaire","profil");
                echo'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                $form->CheckInput("admin","Administrateur","radio","admin","profil");
                echo'</center>';
                $form->buttonInput("submit","soumettre","soumettre","btn btn-success col-md-6");
                $form->buttonInput("reset","Annuler","Annuler","btn btn-danger col-md-6");
            ?>
            </form>
    </div>
</body>
</html>