<?php session_start();
    if (!isset($_SESSION['login'])) {
        header('location:../index.php');
    }
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Temps restant pour la fin du rendez-vous</title>
    <link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
	<script type="text/javascript" src="../style/js/jquery-min.js"></script>
</head>
<body class="bodyConnexion">
    <div class="divConnexion col-md-9">
        <div class="col-md-2"></div>
        <div class="col-md-3 cadre"><p id="minute">15</p>minutes</div>
        <div class="col-md-2 deux">:</div>
        <div class="col-md-3 cadre"><p id="seconde">00</p>secondes</div>
        <div class="col-md-2"></div>
    </div>
    <div class="col-md-9 valider" style="display:none;">
        <form action="../controleur/medecinControleur.php" method="post">
        <button type="submit" class="btn btn-success" name="validerRv">Valider le rendez-vous</button>
        </form>
    </div>
    <script>
       $(document).ready(function(){
          var minute=parseInt($('#minute').html(),10)
          var seconde=parseInt($('#seconde').html(),10)
        
          timer=setInterval(
              function(){
                    if(seconde==0){
                        seconde=9
                        minute--
                        $('#minute').html(minute)
                    }
                        $('#seconde').html(seconde)
                        seconde--
                    if(minute==0 && seconde==0){
                        clearInterval(timer)
                        $('.divConnexion').html($('.valider').html());
                    }
                }
              ,1000)
       })
   </script>
</body>
</html>