<?php
    session_start();
    if (!isset($_SESSION['login'])) {
        header("location:../vue/connexionVue.php");
    }
    include('formCreator.php');
    include('../utilitaire/DataBaseHelper.php');
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
    <title><?php echo $_SESSION['prenom'].' '.$_SESSION['nom'];?></title>
    
</head>
<body>
   <div class="dashboard">  
       <center>
            <img src="../image/doctor.jpg" alt="photo de profil" class="profil">
            <?php
                session_start();
                echo '<div>'.$_SESSION['login'].'</div>';
            ?>
        </center>
        <ul class="ulDashBoard">
            <li class="liDashBoard">Ajout de Medecin</li>
            <li class="liDashBoard">Modification de Medecin</li>
            <li class="liDashBoard">Suppression de Medecin</li>
            <li class="liDashBoard"><a href="../utilitaire/deconnexion.php" class="aDashBoard" >Se deconnecter</a></li>
        </ul>
   </div>
   <div class="rightContain bg-danger">
        <div class="topContain">
            <marquee direction='right' style='color:white; padding-top:20px;font-weight:bold;font-size:30px;'>
            <?php echo $_SESSION['prenom'].' '.$_SESSION['nom'];?> 
            </marquee>
        </div>
        <div class="restContain">
        <?php 
         //SUCCES DE RENDEZ-VOUS
         if(array_key_exists("erreur", $_SESSION)){  
            echo "<div class='alert alert-danger'>"; 
                echo implode($_SESSION['erreur'],"<br>");
            echo"</div>"; 
            unset($_SESSION["erreur"]);}
           //SUCCES DE RENDEZ-VOUS
        if(array_key_exists("success", $_SESSION)){  
            echo "<div class='alert alert-success'>"; 
                echo $_SESSION['success'];
            echo"</div>"; 
            unset($_SESSION["success"]);}
        if(array_key_exists("supprime", $_SESSION)){  
                echo "<div class='alert alert-success'>"; 
                    echo $_SESSION['supprime'];
                echo"</div>"; 
                unset($_SESSION["supprime"]);}
            ?>  
        </div>  
    </div>
   </div> 
   <div class="ajout col-md-12">
    <?php
        $form= new Formulaire();
        echo"<form method='post' action='../controleur/medecinControleur.php'>";
        echo"<div class='col-md-6'>";
        $form->SimpleInput("Prenom du medecin","text","prenomMedecin","Donnez son prenom","");
        $form->SimpleInput("Nom du Medecin","text","nomMedecin","Donnez le nom","");
        $form->SimpleInput("Email du medecin","email","email","email du medecin","");
        echo"<label>Service</label><br/><select class='col-md-12' name='service'>";
        $sql="SELECT idService,libelleService FROM Service ";
        $req=$pdo->prepare($sql);
        $req->execute([]);
        while($donne=$req->fetch()){
            $form->optionInput($donne['idService'],$donne['libelleService']);
        }
        echo"</select>";
        echo"</div>";
        echo"<div class='col-md-6'>";
        $form->SimpleInput("Login du medecin","text","loginMedecin","Donnez son login","");
        $form->SimpleInput("mot de passe du Medecin","password","pwdMedecin","Donnez le nom","");
        $form->SimpleInput("telephone du medecin","text","tel","telephone du medecin","");
        echo"<label>Domaine</label><br/><select class='col-md-12' name='domaine'>";
        $sql="SELECT idDomaine,libelleDomaine FROM Domaine ";
        $req=$pdo->prepare($sql);
        $req->execute([]);
        while($donne=$req->fetch()){
            $form->optionInput($donne['idDomaine'],$donne['libelleDomaine']);
        }
        echo"</select>";
        echo"</div>";
        $form->buttonInput("submit","ajouter","Ajouter le medecin","col-md-12 btn btn-success");
        $form->buttonInput("reset","annuler","Annuler","col-md-12 btn btn-danger");
        echo"</form>";
    ?>

   </div>
   <div class="modif">b</div>
   <div class="sup">
        <table class="table table-striped">
            <th>Prenom</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Telephone</th>
            <th>Service</th>
            <th>Domaine</th>
            <th>Supprimer</th>
            <?php
            $sqlSelectAll="SELECT * FROM Medecin m,Service s,Domaine d
                          WHERE m.idService=s.idService AND m.idDomaine=d.idDomaine";
            $reqAll=$pdo->prepare($sqlSelectAll);
            $reqAll->execute([]);
            while ($donne=$reqAll->fetch()) {?>
                <tr>
                    <td><?php echo $donne['prenomMedecin'];?></td>
                    <td><?php echo $donne['nomMedecin'];?></td>
                    <td><?php echo $donne['email'];?></td>
                    <td><?php echo $donne['telephone'];?></td>
                    <td><?php echo $donne['libelleService'];?></td>
                    <td><?php echo $donne['libelleDomaine'];?></td>
                    <td>
                        <form action="../controleur/medecinControleur.php" method="post">
                        <input type="hidden" value="<?php echo$donne['idMedecin'];?>" name="sup">
                        <input type="submit" value="Supprimer" name="delete" class="btn btn-danger">
                        </form>
                    </td>
                </tr>
            <?php }?>
        </table>
   </div>
   <script src="../style/js/jquery-min.js"></script>
   <script>
           $(document).ready(function(){
           $('.liDashBoard').click(function(){
                if($(this).html()=='Ajout de Medecin'){
                $('.restContain').html($('.ajout').html())
               }if($(this).html()=='Modification de Medecin'){
                $('.restContain').html($('.modif').html())
               }if($(this).html()=='Suppression de Medecin'){
                $('.restContain').html($('.sup').html())
               }
           })
           
       })
   </script>
</body>
</html>