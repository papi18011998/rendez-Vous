<?php
    session_start();
    if (!isset($_SESSION['login'])) {
        header("location:../vue/connexionVue.php");
    }
    include('formCreator.php');
    include('../utilitaire/DataBaseHelper.php');
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
    <title><?php echo $_SESSION['prenom'].' '.$_SESSION['nom'];?></title>
    
</head>
<body>
   <div class="dashboard">
       
       <center>
            <img src="../image/doctor.jpg" alt="photo de profil" class="profil">
            <?php
                session_start();
                echo '<div>'.$_SESSION['login'].'</div>';
            ?>


        </center>
        <ul class="ulDashBoard">
            <li class="liDashBoard">Tableau de Bord</li>
            <li class="liDashBoard">Regarder mes Rendez-vous en attente</li>
            <li class="liDashBoard">Liste de tous mes Rendez-Vous</li>
            <li class="liDashBoard">commencer un rendez-vous</li>
            <li class="liDashBoard"><a href="../utilitaire/deconnexion.php" class="aDashBoard" >Se deconnecter</a></li>
        </ul>
   </div>
   <div class="rightContain">
        <div class="topContain">
            <marquee direction='right' style='color:white; padding-top:20px;font-weight:bold;font-size:30px;'>
            <?php echo $_SESSION['prenom'].' '.$_SESSION['nom'];?> 
            </marquee>
        </div>
        <div class="restContain">
        <?php 
            //SUCCES DE RENDEZ-VOUS
        if(array_key_exists("reussi", $_SESSION)){  
        echo "<div class='alert alert-success'>"; 
            echo $_SESSION['reussi'];
        echo"</div>"; 
        unset($_SESSION["reussi"]);}?>
        </div>  
    </div>
    <div class="bord"></div>
    <div class="organise col-md-12">
    <h1 class="title">Listes des Rendez-vous en attente</h1>
            <table border="2" class="table table-striped col-md-12 col-sm-12">
                <th>Prenom(s) Patient</th>
                <th>Nom Patient</th>
                <th>Adresse du Patient</th>
                <th>Prenom(s) Secretaire</th>
                <th>Nom Secretaire</th>
                <th>Date de rendez-vous</th>
                <th>Debuter rendez-vous</th>
                <?php
                $sqlSelect="SELECT id,adresse,prenomMedecin,nomMedecin,prenomPatient,nomPatient,prenomSecretaire,nomSecretaire,dateRendezVous,etat
                            FROM Medecin m,Patient p,Secretariat s,RendezVous r 
                            WHERE r.id=p.idPatient AND r.idMedecin=? AND m.idMedecin=r.idMedecin AND s.idSecretariat=r.idSecretariat AND r.etat=?";
                $req=$pdo->prepare($sqlSelect);
                $req->execute([$_SESSION['id'],0]);
                while($donne=$req->fetch()){?>
                <tr>
                <td><?php echo $donne['prenomPatient'];?></td>
                <td><?php echo $donne['nomPatient'];?></td>
                <td><?php echo $donne['adresse'];?></td>
                <td><?php echo $donne['prenomSecretaire'];?></td>
                <td><?php echo $donne['nomSecretaire'];?></td>
                <td><?php echo $donne['dateRendezVous'];?></td>
                <td><form action="../controleur/medecinControleur.php" method="POST">
                    <?php  echo'<input type="hidden" value="'.$donne['id'].'" name="id"/>';
                    $form=new Formulaire();
                    $form->buttonInput("submit","demarre","Debuter","btn btn-success col-md-12");
                    ?>
                </form></td>
                </tr>
                <?php }
                ?>
            </table>
    </div>
    <div class="deleteRv">
    <h1 class="title">Listes des Rendez-vous en attente de commencement</h1>
            <table border="2" class="table table-striped col-md-12 col-sm-12">
                <th>Prenom(s) Patient</th>
                <th>Nom Patient</th>
                <th>Adresse du Patient</th>
                <th>Prenom(s) Secretaire</th>
                <th>Nom Secretaire</th>
                <th>Date de rendez-vous</th>
                <th>Debuter rendez-vous</th>
                <?php
                $sqlSelect="SELECT id,adresse,prenomMedecin,nomMedecin,prenomPatient,nomPatient,prenomSecretaire,nomSecretaire,dateRendezVous,etat
                            FROM Medecin m,Patient p,Secretariat s,RendezVous r 
                            WHERE r.id=p.idPatient AND r.idMedecin=? AND m.idMedecin=r.idMedecin AND s.idSecretariat=r.idSecretariat AND r.etat=?";
                $req=$pdo->prepare($sqlSelect);
                $req->execute([$_SESSION['id'],0]);
                while($donne=$req->fetch()){?>
                <tr>
                <td><?php echo $donne['prenomPatient'];?></td>
                <td><?php echo $donne['nomPatient'];?></td>
                <td><?php echo $donne['adresse'];?></td>
                <td><?php echo $donne['prenomSecretaire'];?></td>
                <td><?php echo $donne['nomSecretaire'];?></td>
                <td><?php echo $donne['dateRendezVous'];?></td>
                <td><form action="../controleur/medecinControleur.php" method="POST">
                    <?php  echo'<input type="hidden" value="'.$donne['id'].'" name="id"/>';
                    $form=new Formulaire();
                    $form->buttonInput("submit","demarre","Debuter","btn btn-success col-md-12");
                    ?>
                </form></td>
                </tr>
                <?php }
                ?>
            </table>
    </div>
    <div class="editRv">
    <h1 class="title">Listes de tous vos rendez-vous</h1>
            <table border="2" class="table table-striped col-md-12 col-sm-12">
                <th>Prenom(s) Patient</th>
                <th>Nom Patient</th>
                <th>Adresse du Patient</th>
                <th>Prenom(s) Secretaire</th>
                <th>Nom Secretaire</th>
                <th>Date de rendez-vous</th>
                <th>Etat du rendez-vous</th>
                <?php
                $sqlSelect="SELECT id,adresse,prenomMedecin,nomMedecin,prenomPatient,nomPatient,prenomSecretaire,nomSecretaire,dateRendezVous,etat
                            FROM Medecin m,Patient p,Secretariat s,RendezVous r 
                            WHERE r.id=p.idPatient AND r.idMedecin=? AND m.idMedecin=r.idMedecin AND s.idSecretariat=r.idSecretariat";
                $req=$pdo->prepare($sqlSelect);
                $req->execute([$_SESSION['id']]);
                while($donne=$req->fetch()){?>
                <tr>
                <td><?php echo $donne['prenomPatient'];?></td>
                <td><?php echo $donne['nomPatient'];?></td>
                <td><?php echo $donne['adresse'];?></td>
                <td><?php echo $donne['prenomSecretaire'];?></td>
                <td><?php echo $donne['nomSecretaire'];?></td>
                <td><?php echo $donne['dateRendezVous'];?></td>
                <td><?php $etat=($donne['etat']==1)? 'terminé':'En attente'; echo'<strong style="color:white;">'.$etat.'</strong>';?></td>
                </tr>
                <?php }
                ?>
            </table>
    </div> 
   <script src="../style/js/jquery-min.js"></script>
   <script>
       $(document).ready(function(){
           $('.liDashBoard').click(function(){
               if($(this).html()=='Tableau de Bord'){
                $('.restContain').html($('.bord').html())
               } if($(this).html()=='Regarder mes Rendez-vous en attente'){
                $('.restContain').html($('.organise').html())
               }if($(this).html()=='Liste de tous mes Rendez-Vous'){
                $('.restContain').html($('.editRv').html())
               }if($(this).html()=='commencer un rendez-vous'){
                $('.restContain').html($('.deleteRv').html())
               }
           })
           
       })
   </script>
</body>
</html>