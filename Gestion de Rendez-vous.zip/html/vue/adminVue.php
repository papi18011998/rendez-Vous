<?php
    session_start();
    if (!isset($_SESSION['login'])) {
        header("location:../vue/connexionVue.php");
    }
    include('formCreator.php');
    include('../utilitaire/DataBaseHelper.php');
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../style/css/bootstrap.min.css">
    <title><?php echo $_SESSION['prenom'].' '.$_SESSION['nom'];?></title>
    
</head>
<body>
   <div class="dashboard">
       
       <center>
            <img src="../image/doctor.jpg" alt="photo de profil" class="profil">
            <?php
                session_start();
                echo '<div>'.$_SESSION['login'].'</div>';
            ?>


        </center>
        <ul class="ulDashBoard">
            <li class="liDashBoard">Tableau de Bord</li>
            <li class="liDashBoard"><a href="secretaireSetting.php" class="aDashBoard">Espace Secretaire</a></li>
            <li class="liDashBoard"><a href="medecinSetting.php" class="aDashBoard">Espace Medecin</a></li>
            <li class="liDashBoard"><a href="../utilitaire/deconnexion.php" class="aDashBoard" >Se deconnecter</a></li>
        </ul>
   </div>
   <div class="rightContain bg-danger">
        <div class="topContain">
            <marquee direction='right' style='color:white; padding-top:20px;font-weight:bold;font-size:30px;'>
            <?php echo $_SESSION['prenom'].' '.$_SESSION['nom'];?> 
            </marquee>
        </div>
        <div class="restContain"></div>  
    </div>
   </div> 
   <script src="../style/js/jquery-min.js"></script>
   <script>
           $('.interneMenu').click(function(){
               if($(this).html()=='Ajout de secretaire'){
                //$('.restContain').html($('.ajout').html())
                alert('dip')
               } if($(this).html()=='Modification de secretaire'){
                $('.restContain').html($('.modif').html())
               }if($(this).html()=='Suppression de secretaire'){
                $('.restContain').html($('.sup').html())
               }
           })
           
       })
   </script>
</body>
</html>