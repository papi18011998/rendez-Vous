-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 06, 2019 at 10:53 PM
-- Server version: 5.7.27-0ubuntu0.18.04.1
-- PHP Version: 7.2.19-0ubuntu0.18.04.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Rendez-Vous`
--

-- --------------------------------------------------------

--
-- Table structure for table `Domaine`
--

CREATE TABLE `Domaine` (
  `idDomaine` int(11) NOT NULL,
  `libelleDomaine` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Domaine`
--

INSERT INTO `Domaine` (`idDomaine`, `libelleDomaine`) VALUES
(1, 'pediatrie');

-- --------------------------------------------------------

--
-- Table structure for table `Medecin`
--

CREATE TABLE `Medecin` (
  `idMedecin` int(11) NOT NULL,
  `prenomMedecin` varchar(100) COLLATE utf8_bin NOT NULL,
  `nomMedecin` varchar(100) COLLATE utf8_bin NOT NULL,
  `disponibilite` tinyint(4) NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `login` varchar(100) COLLATE utf8_bin NOT NULL,
  `pwd` varchar(100) COLLATE utf8_bin NOT NULL,
  `telephone` varchar(100) COLLATE utf8_bin NOT NULL,
  `idService` int(11) NOT NULL,
  `idDomaine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Medecin`
--

INSERT INTO `Medecin` (`idMedecin`, `prenomMedecin`, `nomMedecin`, `disponibilite`, `email`, `login`, `pwd`, `telephone`, `idService`, `idDomaine`) VALUES
(1, 'Papa Ibrahima', 'NDIAYE', 0, 'papa@ggg.com', 'papiMedecin', 'passer', '772222222', 1, 1),
(2, 'Djibril', 'NDIAYE', 1, 'ndia', 'djibi', 'ndiaye', '2222222', 1, 1),
(3, 'a', 'a', 1, 'q', 'papiMedecin', 'qq', 'q', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Patient`
--

CREATE TABLE `Patient` (
  `idPatient` int(11) NOT NULL,
  `nomPatient` varchar(100) COLLATE utf8_bin NOT NULL,
  `prenomPatient` varchar(100) COLLATE utf8_bin NOT NULL,
  `adresse` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `Rendez_Vous`
--

CREATE TABLE `Rendez_Vous` (
  `idPatient` int(11) NOT NULL,
  `idMedecin` int(11) NOT NULL,
  `idSecretariat` int(11) NOT NULL,
  `dateRendezVous` date NOT NULL,
  `heureRendezVous` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `Secretariat`
--

CREATE TABLE `Secretariat` (
  `idSecretariat` int(11) NOT NULL,
  `nomSecretaire` varchar(100) COLLATE utf8_bin NOT NULL,
  `prenomSecretaire` varchar(100) COLLATE utf8_bin NOT NULL,
  `emailSecretaire` varchar(100) COLLATE utf8_bin NOT NULL,
  `login` varchar(100) COLLATE utf8_bin NOT NULL,
  `pwd` varchar(100) COLLATE utf8_bin NOT NULL,
  `telephone` varchar(100) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Secretariat`
--

INSERT INTO `Secretariat` (`idSecretariat`, `nomSecretaire`, `prenomSecretaire`, `emailSecretaire`, `login`, `pwd`, `telephone`) VALUES
(1, 'NDIAYE', 'Papa Ibrahima', 'papaibrahima98@gmail.com', 'papi', 'passer', '776692537'),
(2, 'qq', 'qqqq', 'qqq', 'papi', 'papi', 'qqqqq');

-- --------------------------------------------------------

--
-- Table structure for table `Service`
--

CREATE TABLE `Service` (
  `idService` int(11) NOT NULL,
  `libelleService` varchar(50) COLLATE utf8_bin NOT NULL,
  `idSecretariat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Service`
--

INSERT INTO `Service` (`idService`, `libelleService`, `idSecretariat`) VALUES
(1, 'orl', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Specialite`
--

CREATE TABLE `Specialite` (
  `idSpecialite` int(11) NOT NULL,
  `libelleSpecialite` varchar(50) COLLATE utf8_bin NOT NULL,
  `idService` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `Specialite`
--

INSERT INTO `Specialite` (`idSpecialite`, `libelleSpecialite`, `idService`) VALUES
(1, 'orl2', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Domaine`
--
ALTER TABLE `Domaine`
  ADD PRIMARY KEY (`idDomaine`);

--
-- Indexes for table `Medecin`
--
ALTER TABLE `Medecin`
  ADD PRIMARY KEY (`idMedecin`),
  ADD KEY `Medecin_Service_FK` (`idService`),
  ADD KEY `Medecin_Domaine0_FK` (`idDomaine`);

--
-- Indexes for table `Patient`
--
ALTER TABLE `Patient`
  ADD PRIMARY KEY (`idPatient`);

--
-- Indexes for table `Rendez_Vous`
--
ALTER TABLE `Rendez_Vous`
  ADD PRIMARY KEY (`idPatient`,`idMedecin`,`idSecretariat`),
  ADD KEY `Rendez_Vous_Medecin0_FK` (`idMedecin`),
  ADD KEY `Rendez_Vous_Secretariat1_FK` (`idSecretariat`);

--
-- Indexes for table `Secretariat`
--
ALTER TABLE `Secretariat`
  ADD PRIMARY KEY (`idSecretariat`);

--
-- Indexes for table `Service`
--
ALTER TABLE `Service`
  ADD PRIMARY KEY (`idService`),
  ADD KEY `Service_Secretariat_FK` (`idSecretariat`);

--
-- Indexes for table `Specialite`
--
ALTER TABLE `Specialite`
  ADD PRIMARY KEY (`idSpecialite`),
  ADD KEY `Specialite_Service_FK` (`idService`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Domaine`
--
ALTER TABLE `Domaine`
  MODIFY `idDomaine` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Medecin`
--
ALTER TABLE `Medecin`
  MODIFY `idMedecin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Patient`
--
ALTER TABLE `Patient`
  MODIFY `idPatient` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Secretariat`
--
ALTER TABLE `Secretariat`
  MODIFY `idSecretariat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Service`
--
ALTER TABLE `Service`
  MODIFY `idService` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Specialite`
--
ALTER TABLE `Specialite`
  MODIFY `idSpecialite` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Medecin`
--
ALTER TABLE `Medecin`
  ADD CONSTRAINT `Medecin_Domaine0_FK` FOREIGN KEY (`idDomaine`) REFERENCES `Domaine` (`idDomaine`),
  ADD CONSTRAINT `Medecin_Service_FK` FOREIGN KEY (`idService`) REFERENCES `Service` (`idService`);

--
-- Constraints for table `Rendez_Vous`
--
ALTER TABLE `Rendez_Vous`
  ADD CONSTRAINT `Rendez_Vous_Medecin0_FK` FOREIGN KEY (`idMedecin`) REFERENCES `Medecin` (`idMedecin`),
  ADD CONSTRAINT `Rendez_Vous_Patient_FK` FOREIGN KEY (`idPatient`) REFERENCES `Patient` (`idPatient`),
  ADD CONSTRAINT `Rendez_Vous_Secretariat1_FK` FOREIGN KEY (`idSecretariat`) REFERENCES `Secretariat` (`idSecretariat`);

--
-- Constraints for table `Service`
--
ALTER TABLE `Service`
  ADD CONSTRAINT `Service_Secretariat_FK` FOREIGN KEY (`idSecretariat`) REFERENCES `Secretariat` (`idSecretariat`);

--
-- Constraints for table `Specialite`
--
ALTER TABLE `Specialite`
  ADD CONSTRAINT `Specialite_Service_FK` FOREIGN KEY (`idService`) REFERENCES `Service` (`idService`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
